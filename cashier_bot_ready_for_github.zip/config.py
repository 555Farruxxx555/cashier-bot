
# 🔐 Токен твоего Telegram-бота от @BotFather
BOT_TOKEN = "8043904338:AAG6Hm-ByyLjpniVMnY3mPg8g9rDb_FEyms"

# 👤 Список Telegram ID админов, которые будут получать уведомления
ADMIN_IDS = [2033317678]

# 💳 Список карт для приёма платежей (RECEIVER_CARDS)
RECEIVER_CARDS = [
    "9860120118232798"
]

# 📍 Адреса, куда клиент может прийти при выводе (если используется)
WITHDRAW_LOCATIONS = [
    "Andijon | Lermontov ko'chasi"
]
