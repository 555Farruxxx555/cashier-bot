import random

CARDS = [
    "9860120118232798",
    "9860020111223344",
    "8600123456789012"
]

def get_random_card():
    return random.choice(CARDS)
